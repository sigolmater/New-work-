# engine/ray.py
from dataclasses import dataclass
from .vec import unit
from .cube import next_hit, reflect
@dataclass
class Ray:
    pos: tuple
    dir: tuple
def step(r):
    hit,side=next_hit(r.pos,r.dir)
    if not side: return r,None
    return Ray(hit, reflect(r.dir,side)), side
def run(r,bounces):
    r=Ray(r.pos, unit(r.dir)); hist=[]
    for _ in range(bounces):
        r,side=step(r)
        if not side: break
        hist.append((r.pos,side))
    return r,hist
