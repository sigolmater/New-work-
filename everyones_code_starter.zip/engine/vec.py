# engine/vec.py
import math
def dot(a,b): return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]
def add(a,b): return (a[0]+b[0],a[1]+b[1],a[2]+b[2])
def mul(a,s): return (a[0]*s,a[1]*s,a[2]*s)
def unit(a):
    n=math.sqrt(dot(a,a))
    return (a[0]/n,a[1]/n,a[2]/n) if n else (0.0,0.0,0.0)
