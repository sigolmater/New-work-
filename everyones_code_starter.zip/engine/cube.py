# engine/cube.py
from .vec import add, mul
def next_hit(pos, dirv):
    tbest=None; side=None
    for i,(p,d) in enumerate(zip(pos,dirv)):
        if d>0:  t=(1.0-p)/d; s=(i,+1)
        elif d<0:t=(-1.0-p)/d; s=(i,-1)
        else:    continue
        if t>1e-12 and (tbest is None or t<tbest):
            tbest,side=t,s
    if tbest is None: return None,None
    hit=add(pos, mul(dirv, tbest)); return hit,side
def reflect(dirv, side):
    axis,_=side; d=list(dirv); d[axis]=-d[axis]; return (d[0],d[1],d[2])
