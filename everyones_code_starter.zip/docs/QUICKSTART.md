# QUICK START
## 1) 로컬 실행(선택)
python verification/tests.py
python experiments/run.py --rays 200 --bounces 120 --seed 7 --out outputs/exp.csv
python -m pip install matplotlib
python experiments/plot.py outputs/exp.csv

## 2) GitHub Actions 자동 실행
- `.github/workflows/everyone-loop.yml`이 매 시 정각에 실행됩니다.
- 결과는 `outputs/` 폴더에 CSV/PNG로 쌓입니다.
