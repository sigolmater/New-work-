#!/usr/bin/env python3
# orchestrator_sigol.py — 오케스트레이터 + 시골-명 라우팅
import os, json, csv, argparse, datetime, urllib.request
import strategy_router as SR

API_CHAT = "https://models.github.ai/inference/chat/completions"

def gh_request(url, payload=None):
    token = os.environ.get("GH_TOKEN") or os.environ.get("GITHUB_TOKEN")
    if not token:
        raise RuntimeError("GH_TOKEN or GITHUB_TOKEN is required")
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {token}",
        "X-GitHub-Api-Version": "2022-11-28"
    }
    req = urllib.request.Request(url, headers=headers, method="POST" if payload else "GET")
    if payload:
        data = json.dumps(payload).encode("utf-8")
        req.data = data
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read().decode("utf-8"))

def call_chat(model, system_prompt, user_prompt, temperature=0.4, max_tokens=800):
    payload = {
        "model": model,
        "messages": [
            {"role":"system","content": system_prompt},
            {"role":"user","content": user_prompt}
        ],
        "temperature": temperature,
        "max_tokens": max_tokens
    }
    resp = gh_request(API_CHAT, payload)
    return resp["choices"][0]["message"]["content"]

def select_today_seed(csv_path):
    import datetime as dt
    today = dt.date.today().isoformat()
    if not os.path.exists(csv_path):
        return {"date":None,"format":None,"seed":"행동의 불","cta":None}
    rows = []
    with open(csv_path, "r", encoding="utf-8") as f:
        rdr = csv.reader(f); header = next(rdr, None)
        for row in rdr: rows.append(row)
    for date, fmt, seed, cta in rows:
        if date == today:
            return {"date":date,"format":fmt,"seed":seed,"cta":cta}
    return {"date":None,"format":None,"seed":rows[0][2] if rows else "행동의 불","cta":None}

def write_output(title, content):
    ts = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    os.makedirs("outputs", exist_ok=True)
    safe = "".join(c for c in title if c.isalnum() or c in ("-","_"))
    path = os.path.join("outputs", f"{ts}--{safe}.md")
    open(path,"w",encoding="utf-8").write(content)
    return path

def run(mode, model="openai/gpt-4o-mini"):
    # 라더 결정: env SIGOL_ROUTE (옵션) → 자동 결정
    env_hint = os.environ.get("SIGOL_ROUTE")
    route = SR.decide_route(env_hint=env_hint)
    system_prompt = "준비운동 시스템 — 신중·단계·깊이. 라더에 따라 프롬프트를 적응."
    if mode == "ideation":
        base_prompt = "오늘 주제 씨앗 5개를 불릿으로."
    elif mode == "script":
        seed = select_today_seed("content_calendar.csv")["seed"]
        base_prompt = f"HPRC 3분 스크립트. 주제: {seed}"
    elif mode == "publish-log":
        transcript = os.environ.get("TRANSCRIPT_TEXT","")
        base_prompt = f"다음 텍스트를 5줄로 요약하고 실행 CTA 1개: {transcript[:2000]}"
    else:
        raise SystemExit("unknown mode")

    user_prompt = SR.adapt_prompt(route, base_prompt)
    out = call_chat(model, system_prompt, user_prompt, temperature=0.4, max_tokens=800)
    p = write_output(f"{mode}--{route}", out)
    SR.log_route(route, status="OK", note=p)
    print(p)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["ideation","script","publish-log"], required=True)
    ap.add_argument("--model", default="openai/gpt-4o-mini")
    args = ap.parse_args()
    run(args.mode, args.model)
