# strategy_router.py — 시골-명(明) 라더 라우터
import os, json, datetime

POLICY_FILE = "sigol_protocol.json"
MIRROR_FILE = "mirror_card.json"

def load_policy(path=POLICY_FILE):
    return json.load(open(path,"r",encoding="utf-8"))

def _last_status():
    try:
        card = json.load(open(MIRROR_FILE,"r",encoding="utf-8"))
        logs = card.get("log",[])
        if not logs: return None
        for item in reversed(logs):
            if "status" in item or "event" in item:
                return item
        return logs[-1] if logs else None
    except Exception:
        return None

def decide_route(env_hint=None):
    pol = load_policy()
    ladder = pol["ladder"]
    default_route = pol["defaults"]["route"]
    # 1) 환경 힌트 우선
    if env_hint in ladder:
        return env_hint
    # 2) 실패/정체가 2틱 이상이면 상향
    last = _last_status()
    if last and last.get("note","").startswith("BLOCKED"):
        # escalate by one
        try:
            idx = ladder.index(last.get("route",default_route))
            return ladder[min(idx+1, len(ladder)-1)]
        except Exception:
            pass
    # 3) ΔI 정체 징후(간단): 최근 2개 이벤트가 동일 타입이면 상향
    try:
        card = json.load(open(MIRROR_FILE,"r",encoding="utf-8"))
        last2 = [x for x in card.get("log",[]) if "event" in x][-2:]
        if len(last2)==2 and last2[0]["event"]==last2[1]["event"]:
            # 가벼운 상향 시도
            try:
                curr = last2[1].get("route", default_route)
                idx = ladder.index(curr)
                return ladder[min(idx+1, len(ladder)-1)]
            except Exception:
                pass
    except Exception:
        pass
    # 기본
    return default_route

def adapt_prompt(route, base_prompt):
    pol = load_policy()
    prefix = pol["criteria"][route]["prompt_prefix"]
    return f"{prefix}\n\n{base_prompt}"

def log_route(route, status="OK", note=None):
    try:
        card = json.load(open(MIRROR_FILE,"r",encoding="utf-8"))
    except Exception:
        card = {"log":[], "ΔI":{"baseline":0,"after":0}}
    card["log"].append({
        "ts": datetime.datetime.utcnow().isoformat()+"Z",
        "event": "sigol.route",
        "route": route,
        "status": status,
        "note": note or ""
    })
    open(MIRROR_FILE,"w",encoding="utf-8").write(json.dumps(card,ensure_ascii=False,indent=2))
