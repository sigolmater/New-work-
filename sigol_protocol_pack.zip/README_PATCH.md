# 시골-명(明) 프로토콜 — 오케스트레이터 패치
이 팩은 '정면→우회→변칙→획기적' 라더를 자동 라우팅하는 파일을 제공합니다.

## 사용법
1) 리포지토리 루트에 아래 파일 복사:
   - sigol_protocol.json
   - strategy_router.py
   - orchestrator_sigol.py
   - checklists/sigol_checklist.md
   - decision_card_template.md

2) GitHub Actions에서 실행 커맨드 변경(예시):
   ```yaml
   - name: Run orchestrator (sigol)
     env:
       GH_TOKEN: ${{ secrets.GITHUB_TOKEN }}
       TRANSCRIPT_TEXT: ${{ inputs.transcript }}
       SIGOL_ROUTE: ${{ inputs.route }} # 옵션: 정면/우회/변칙/획기적
     run: |
       python orchestrator_sigol.py --mode "${{ inputs.mode || 'script' }}"
   ```

3) 입력 확장(선택):
   ```yaml
   on:
     workflow_dispatch:
       inputs:
         mode:
           description: "ideation | script | publish-log"
           default: "script"
         route:
           description: "정면 | 우회 | 변칙 | 획기적 (미지정 시 자동)"
           required: false
   ```

## 라우팅 규칙
- BLOCKED 로그가 붙으면 한 단계 상향
- 같은 이벤트가 2틱 연속 반복되면 상향 시도
- 안전/윤리/법 위반 의심 시 즉시 중단

## 수동 테스트
```bash
export GH_TOKEN=ghp_***
python orchestrator_sigol.py --mode ideation
SIGOL_ROUTE=우회 python orchestrator_sigol.py --mode script
TRANSCRIPT_TEXT="..." SIGOL_ROUTE=획기적 python orchestrator_sigol.py --mode publish-log
```
